$(document).ready(function() {


    $('.owl-carousel').owlCarousel({
        margin:  9,
    });

});